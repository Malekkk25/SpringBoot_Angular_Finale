export class Aeroport {
    idAir! : number; 
    adresseAir! : string;
    nomAir! : string;
    }    