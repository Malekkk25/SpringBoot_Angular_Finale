export class Image {
    idImage! : number ;
    name! : string ;
    type !: string ;
    image !: number[] ;
    }
    