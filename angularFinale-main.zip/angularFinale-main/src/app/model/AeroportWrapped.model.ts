import { Aeroport } from "./aeroport.model"; 
export class AeroportWrapper{
_embedded!: { aeroports: Aeroport[]};}//format
